# jQuery-fireworks
A jQuery plugin that puts dazzling fireworks into a div

# Usage
$('#divElement').fireworks();

There are optional parameters as well:
$('#divElement').fireworks({
    sound: true,
    opacity: 0.4,
    width: '400',
    height: '300'
});
